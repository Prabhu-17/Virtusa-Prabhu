package TestNG;

import org.junit.Test;

public class Test1 
{
	@Test
	public void testMethod1()
	{
		System.out.println("Test 1 method");
	}

}
