package ui;

import org.openqa.selenium.By;

public class cucumber {

	public static void main(String[] args) 
	{

	}

}
